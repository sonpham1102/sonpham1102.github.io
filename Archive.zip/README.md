# Decimation's Cydia Repository

Welcome to my Cydia repo! It's full of wonderful themes and a couple of tweaks.

Add this source in Cydia!

# Repo creation

If you're here from my [Reddit tutorial](https://www.reddit.com/r/jailbreak/comments/3cc4fn/tutorial_how_to_set_up_a_repo_using_github_pages/), feel free to dig through my repo. Please give some credit in your readme or any other way. Thanks!

# Contact
You can contact me on Reddit at /u/_Decimation or on Twitter at @dec1mati0n.
